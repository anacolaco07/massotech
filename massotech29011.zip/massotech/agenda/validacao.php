<?php
session_start()
if(!isset($_SESSION["id_usuario"])){
    header("Location: ../login/login.php");
} else{
?>

<?php
require "../Config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $dataHoraAgendamento = $_POST["dataHoraAgendamento"];
        $procedimento = $_POST["procedimento"];
        $id_paciente = $_POST["id_paciente"];

        if (empty($dataHoraAgendamento) || empty($procedimento) || empty($id_paciente)) {
            echo "Preencha todos os campos obrigatórios.";
        } else {
            $dataAtual = new DateTime();
            $dataAgendamento = new DateTime($dataHoraAgendamento);

            if ($dataAgendamento < $dataAtual) {
                echo "<script>alert('A data de agendamento não pode ser anterior à data atual.'); window.location.href='../agenda/agenda.php';</script>";
                exit();
            } else {
                $inserir = $pdo->prepare("INSERT INTO tb_agendamento (data_hora_agendamento, procedimento, id_paciente) VALUES (:dataHoraAgendamento, :procedimento, :id_paciente)");
                $inserir->bindParam(":dataHoraAgendamento", $dataAgendamento->format('Y-m-d H:i:s'));
                $inserir->bindParam(":procedimento", $procedimento);
                $inserir->bindParam(":id_paciente", $id_paciente);

                try {
                    if ($inserir->execute()) {
                        echo "Agendamento realizado com sucesso!";
                    } else {
                        echo "Erro ao agendar. Tente novamente.";
                    }
                } catch (Exception $ex) {
                    echo "Erro ao executar a inserção no banco de dados: " . $ex->getMessage();
                }
            }
        }
    } catch (Exception $e) {
        echo "Erro geral: " . $e->getMessage();
    }
}
?>
<?php
}
?>