<!DOCTYPE html>
<html>
<head>
    <title>Formulário de Relatório</title>
</head>
<body>
    <h1>Selecione os campos para gerar o relatório</h1>
    <form action="gerar_relatorio.php" method="POST">
        <label for="campo_procedimento">Técnica aplicada</label>
        <input type="checkbox" name="campos[]" id="campo_procedimento" value="procedimento">
        <br>

         <label for="sexo_masculino">Sexo do Paciente: Masculino</label>
        <input type="checkbox" name="campos[]" id="sexo_masculino" value="masculino">
        <br>
        <label for="sexo_feminino">Sexo do Paciente: Feminino</label>
        <input type="checkbox" name="campos[]" id="sexo_feminino" value="feminino">
        <br>
        <label for="sexo_outro">Sexo do Paciente: Outro</label>
        <input type="checkbox" name="campos[]" id="sexo_outro" value="outro">
        <br>

        <label for="dataNascimentoMin">Data de Nascimento Minima</label>
        <input type="date" name="dataNascimentoMin" id="dataNascimentoMin">
        <br>
        
        <label for="dataNascimentoMax">Data de Nascimento Maxima</label>
        <input type="date" name="dataNascimentoMax" id="dataNascimentoMax">
        <br>
        
        <input type="submit" value="Gerar Relatório">
    </form>
    <a href='../main_page/index.php'>Voltar</a>
</body>
</html>
