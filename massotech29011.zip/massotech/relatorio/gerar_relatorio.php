<?php
require_once "../Config.php";

// This function calculates age from a birthdate
function calcularIdade($data_nascimento)
{
    $data_nascimento = new DateTime($data_nascimento);
    $data_atual = new DateTime();
    $diferenca = $data_atual->diff($data_nascimento);
    return $diferenca->y;
}

// Handle a POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo $_POST['dataNascimentoMax'];
    echo "<BR>";
    echo $_POST['dataNascimentoMin'];

    $dtMin = $_POST['dataNascimentoMin'];
    $dtMax = $_POST['dataNascimentoMax'];
    $sexoM = $_POST['sexo_masculino'];

    $sql = "select * from tb_paciente where ";

    if (in_array('masculino', $_POST['campos']) || in_array('feminino', $_POST['campos'])) {
        $campos_selecionados[] = 'sexo';
    }
    
    
    
    
    if (! empty($dtMin)) {
        $sql . " dataNascimentoMin = " . $dtMin . " ";
    }

    if (! empty($dtMax)) {
        $sql . " dataNascimentoMax = " . $dtMax . " ";
    }

    if (sexo_masculino) {
        $sql . " sexo = " . $sexo . " ";
    }

    if ($sexo == 'feminino') {
        $sql . " sexo = " . $sexo . " ";
    }

    if ($sexo == 'outro') {
        $sql . " sexo = " . $sexo . " ";
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    
    $relatorios = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // $sql = "SELECT * FROM tb_Paciente WHERE data_nascimento BETWEEN.$_POST['dataNascimentoMin'] AND $_POST['dataNascimentoMax']";
}
?>
