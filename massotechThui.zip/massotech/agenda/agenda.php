<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="agenda.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">    
    <title>Agenda</title>
</head>

<body>

<div id="menu-lateral">
  <a href="../main_page/index.php">
    <i class="fas fa-home"></i> Início
  </a>
  <a href="../agenda/agenda.php">
    <i class="fas fa-calendar"></i> Agenda
  </a>
  <a href="../paciente/paciente.php">
    <i class="fas fa-users"></i> Pacientes
  </a>
  <a href="../perfil/view_perfil.php">
    <i class="fas fa-user"></i> Perfil
  </a>
  <a href="../main_page/index.php">
    <i class="fas fa-sign-out-alt"></i> Sair
  </a>
</div>

<div class="conteudo">
    <h2>Agenda</h2>
    <form action="../agenda/validacao.php" method="post">
        <label for="idPaciente">ID do Paciente</label>
        <input type="number" name="id_paciente" id="id_paciente">
        <br>
        <label for="procedimento">Massagem</label>
        <select name="procedimento">
            <!-- Opções do select -->
        </select>
        <br>
        <label for="dataHoraAgendamento">Data e Hora</label>
        <input type="datetime-local" name="dataHoraAgendamento" id="dataHoraAgendamento">
        <br>
        <input type="submit" value="Agendar">
    </form>
    <a href="../main_page/index.php">Voltar</a>
</div>

</body>
</html>
