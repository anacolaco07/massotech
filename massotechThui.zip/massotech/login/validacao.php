<?php
session_start();
require_once '../Config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $senha = md5($_POST["senha"]);
    
    if (empty($email) || empty($senha)) {
        echo "Por favor, preencha os campos.";
    } else {
        $select = $pdo->prepare("SELECT id, senha FROM tb_usuario WHERE email = ?");
        $select->bindParam(1, $email);
        $select->execute();
        
        if ($select->rowCount() > 0) {
            $row = $select->fetch(PDO::FETCH_ASSOC);
            $senha_hash = $row["senha"];
            
            if ($senha === $senha_hash) {
                $_SESSION["id_usuario"] = $row['id'];
                header("Location: ../main_page/index.php");
                exit();
            } else {
                echo "Credenciais inválidas.";
                echo "<br/>";
                echo "<a href='../login/login.php'>Voltar</a>";
            }
        } else {
            echo "Usuário não encontrado.";
            echo "<br/>";
            echo "<a href='../login/login.php'>Voltar</a>";
        }
    }
}
?>
