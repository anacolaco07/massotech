<?php
// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $partesSelecionadas = [];

    // Lista de todos os possíveis campos do formulário
    $todosCampos = [
        'cranio',
        'face',
        'regiao_occipital',
        'ombro_direito',
        'ombro_esquerdo',
        'braco_direito',
        'braco_esquerdo',
        'antebraco_direito',
        'antebraco_esquerdo',
        'punho_direito',
        'punho_esquerdo',
        'mao_direita',
        'mao_esquerda',
        'peitoral',
        'abdomen',
        'regiao_escapular',
        'regiao_cervical',
        'regiao_toracica',
        'regiao_lombar',
        'regiao_sacral',
        'regiao_coccigea',
        'regiao_glutea',
        'regiao_dorsal',
        'quadril',
        'coxa_anterior_direita',
        'coxa_anterior_esquerda',
        'coxa_posterior_direita',
        'coxa_posterior_esquerda',
        'coxa_lateral_direita',
        'coxa_lateral_esquerda',
        'coxa_medial_direita',
        'coxa_medial_esquerda',
        'perna_anterior_direita',
        'perna_anterior_esquerda',
        'perna_posterior_direita',
        'perna_posterior_esquerda',
        'tornozelo_direito',
        'tornozelo_esquerdo',
        'pe_direito',
        'pe_esquerdo'
    ];

    // Verifica quais campos foram marcados
    foreach ($todosCampos as $campo) {
        if (isset($_POST[$campo])) {
            $partesSelecionadas[] = $campo;
        }
    }

    // Exibe os campos selecionados
    echo "Campos selecionados: " . implode(', ', $partesSelecionadas);
}
?>
