<?php
require_once '../Config.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Formulário de Partes do Corpo</title>
</head>
<body>

<form action="evolucao_formulario.php" method="post">
    <label><input type="checkbox" name="partesCorpo[cranio]" value="1"> Crânio</label><br>
    <label><input type="checkbox" name="partesCorpo[face]" value="1"> Face</label><br>
    <label><input type="checkbox" name="partesCorpo[regiao_occipital]" value="1"> Região Occipital</label><br>
    <label><input type="checkbox" name="partesCorpo[ombro_direito]" value="1"> Ombro Direito</label><br>
    <label><input type="checkbox" name="partesCorpo[ombro_esquerdo]" value="1"> Ombro Esquerdo</label><br>
    <label><input type="checkbox" name="partesCorpo[braco_direito]" value="1"> Braço Direito</label><br>
    <label><input type="checkbox" name="partesCorpo[braco_esquerdo]" value="1"> Braço Esquerdo</label><br>
    <label><input type="checkbox" name="partesCorpo[antebraco_direito]" value="1"> Antebraço Direito</label><br>
    <label><input type="checkbox" name="partesCorpo[antebraco_esquerdo]" value="1"> Antebraço Esquerdo</label><br>
    <label><input type="checkbox" name="partesCorpo[punho_direito]" value="1"> Punho Direito</label><br>
    <label><input type="checkbox" name="partesCorpo[punho_esquerdo]" value="1"> Punho Esquerdo</label><br>
    <label><input type="checkbox" name="partesCorpo[mao_direita]" value="1"> Mão Direita</label><br>
    <label><input type="checkbox" name="partesCorpo[mao_esquerda]" value="1"> Mão Esquerda</label><br>
    <label><input type="checkbox" name="partesCorpo[peitoral]" value="1"> Peitoral</label><br>
    <label><input type="checkbox" name="partesCorpo[abdomen]" value="1"> Abdomen</label><br>
    <label><input type="checkbox" name="partesCorpo[regiao_escapular]" value="1"> Região Escapular</label><br>
    <label><input type="checkbox" name="partesCorpo[regiao_cervical]" value="1"> Região Cervical</label><br>
    <label><input type="checkbox" name="partesCorpo[regiao_toracica]" value="1"> Região Torácica</label><br>
    <label><input type="checkbox" name="partesCorpo[regiao_lombar]" value="1"> Região Lombar</label><br>
    <label><input type="checkbox" name="partesCorpo[regiao_sacral]" value="1"> Região Sacral</label><br>
    <label><input type="checkbox" name="partesCorpo[regiao_coccigea]" value="1"> Região Coccígea</label><br>
    <label><input type="checkbox" name="partesCorpo[regiao_glutea]" value="1"> Região Glútea</label><br>
    <label><input type="checkbox" name="partesCorpo[regiao_dorsal]" value="1"> Região Dorsal</label><br>
    <label><input type="checkbox" name="partesCorpo[quadril]" value="1"> Quadril</label><br>	
    <label><input type="checkbox" name="partesCorpo[coxa_anterior_direita]" value="1"> Coxa Anterior Direita</label><br>
    <label><input type="checkbox" name="partesCorpo[coxa_anterior_esquerda]" value="1"> Coxa Anterior Esquerda</label><br>
    <label><input type="checkbox" name="partesCorpo[coxa_posterior_direita]" value="1"> Coxa Posterior Direita</label><br>
    <label><input type="checkbox" name="partesCorpo[coxa_posterior_esquerda]" value="1"> Coxa Posterior Esquerda</label><br>
    <label><input type="checkbox" name="partesCorpo[coxa_lateral_direita]" value="1"> Coxa Lateral Direita</label><br>
    <label><input type="checkbox" name="partesCorpo[coxa_lateral_esquerda]" value="1"> Coxa Lateral Esquerda</label><br>
    <label><input type="checkbox" name="partesCorpo[coxa_medial_direita]" value="1"> Coxa Medial Direita</label><br>
    <label><input type="checkbox" name="partesCorpo[coxa_medial_esquerda]" value="1"> Coxa Medial Esquerda</label><br>
    <label><input type="checkbox" name="partesCorpo[perna_anterior_direita]" value="1"> Perna Anterior Direita</label><br>
    <label><input type="checkbox" name="partesCorpo[perna_anterior_esquerda]" value="1"> Perna Anterior Esquerda</label><br>
    <label><input type="checkbox" name="partesCorpo[perna_posterior_direita]" value="1"> Perna Posterior Direita</label><br>
    <label><input type="checkbox" name="partesCorpo[perna_posterior_esquerda]" value="1"> Perna Posterior Esquerda</label><br>
    <label><input type="checkbox" name="partesCorpo[tornozelo_direito]" value="1"> Tornozelo Direito</label><br>
    <label><input type="checkbox" name="partesCorpo[tornozelo_esquerdo]" value="1"> Tornozelo Esquerdo</label><br>
    <label><input type="checkbox" name="partesCorpo[pe_direito]" value="1"> Pé Direito</label><br>
    <label><input type="checkbox" name="partesCorpo[pe_esquerdo]" value="1"> Pé Esquerdo</label><br>
    <label><input type="text" name="detalhamento" value=""> Detalhamento</label><br>
    <input type="submit" value="Enviar">
</form>

</body>
</html>
