<?php
require_once "../Config.php";

function calcularIdade($data_nascimento) {
    $data_nascimento = new DateTime($data_nascimento);
    $data_atual = new DateTime();
    $diferenca = $data_atual->diff($data_nascimento);
    return $diferenca->y;
}
if (isset($_GET['id_paciente'])) {
    $id_paciente = $_GET['id_paciente'];
    
    $sql = "SELECT * FROM tb_paciente WHERE id_paciente = :id_paciente";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id_paciente', $id_paciente);
    $stmt->execute();
    
    $paciente = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($paciente) {
        echo "ID: " . $paciente['id_paciente'] . "<br>";
        echo "Nome: " . $paciente['nome_paciente'] . "<br>";
        echo "Sexo: " . $paciente['sexo'] . "<br>";
        $idade = calcularIdade($paciente['data_nascimento']);
        echo "Idade: " . $idade  . "<br>";
        echo "Email : " . $paciente['email_paciente'] . "<br>";
        echo "Telefone: " . $paciente['telefone_paciente'] . "<br>";
        echo "Data de nascimento: " . $paciente['data_nascimento'] . "<br>";
        echo "Profissão: " . $paciente['profissao'] . "<br>";
        echo "Setor: " . $paciente['setor'] . "<br>";
        echo "Função: " . $paciente['funcao'] . "<br>";
        echo "Tempo que exerce: " . $paciente['tempo_que_exerce'] . "<br>";
        echo "Postura corporal adotada no trabalho: " . $paciente['postura_corporal'] . "<br>";
        echo "Já teve COVID-19? " . $paciente['ja_teve_covid'] . "<br>";
        echo "Se sim, quando?(ano e mês): " . $paciente['quando_ano'] . " " . $paciente['quando_mes'] . "<br>";
        echo "Está vacinado? " . $paciente['esta_vacinado'] . "<br>";
        echo "Doenças pregressas: " . $paciente['doencas_pregressas'] . "<br>";
        echo "Doença atual: " . $paciente['doenca_atual'] . "<br>";
        echo "Queixas principais: " . $paciente['queixas_principais'] . "<br>";
        echo "Processos cirurgicos: " . $paciente['processos_cirurgicos'] . "<br>";
        echo "Medicamentos: " . $paciente['medicamentos'] . "<br>";
        echo "Realiza alguma atividade física ou tratamento de reabilitação? " . $paciente['realiza_atividade_fisica'] . "<br>";
        echo "Se sim, qual(is)? " . $paciente['qual_atividade_fisica'] . "<br>";
        echo "Qual a frenquência? " . $paciente['qual_frequencia'] . "<br>";
        echo "Motivo da procura pela massoterapia: " . $paciente['motivo_procura'] . "<br>";
        echo "</br>";
        echo "<a href='../main_page/index.php'>Voltar</a>";
        echo "</br>";
        echo "<a href='../agenda/agenda.php'>Nova Sessão</a>";
        
        
    } else {
        echo "Paciente não encontrado.";
    }
} else {
    echo "ID do paciente não especificado.";
}
?>
