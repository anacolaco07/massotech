CREATE DATABASE projeto_login;
USE projeto_login;

CREATE TABLE tb_usuario (
  id bigint NOT NULL AUTO_INCREMENT,
  nome varchar(255)  DEFAULT NULL,
  email varchar(100) DEFAULT NULL,
  senha varchar(255) DEFAULT NULL,
  telefone varchar(20) DEFAULT NULL,
  PRIMARY KEY (id),
  CONSTRAINT unico UNIQUE (email)
) ENGINE=InnoDB;

CREATE TABLE tb_Paciente(
id_paciente bigint NOT NULL AUTO_INCREMENT,
nome_paciente varchar(255) DEFAULT NULL,
sexo enum("feminino","masculino","outro"),
email_paciente varchar(100) DEFAULT NULL,
telefone_paciente varchar(20) DEFAULT NULL,
data_nascimento date DEFAULT NULL,
profissao varchar(255)  DEFAULT NULL,
setor varchar(255) DEFAULT NULL,
funcao varchar(255)  DEFAULT NULL,
tempo_que_exerce int ,
postura_corporal enum("sentada","em pé", "mista"),
ja_teve_covid enum("sim","não") ,
quando_ano int DEFAULT NULL,
quando_mes enum ("janeiro", "fevereiro", "março", "abril","maio", "junho", "julho","agosto","setembro", "outubro","novembro","dezembro"),
esta_vacinado enum("sim","não") ,
doencas_pregressas varchar(255) ,
doenca_atual varchar(255) DEFAULT NULL,
queixas_principais varchar(255) DEFAULT NULL,
processos_cirurgicos varchar(255) DEFAULT NULL,
medicamentos varchar(255) DEFAULT NULL,
realiza_atividade_fisica enum("sim","não"),
qual_atividade_fisica varchar(255) DEFAULT NULL,
qual_frequencia varchar(255) DEFAULT NULL,
motivo_procura varchar(255) DEFAULT NULL,
PRIMARY KEY (id_paciente)
);

CREATE TABLE tb_Agendamento (
  id_agendamento bigint NOT NULL AUTO_INCREMENT,
  id_paciente bigint NOT NULL,
  data_hora_agendamento datetime NOT NULL,
  procedimento varchar(50) NOT NULL,
  PRIMARY KEY (id_agendamento),
  FOREIGN KEY (id_paciente) REFERENCES tb_Paciente(id_paciente)
);

CREATE TABLE tb_partesCorpo (
    id_partesCorpo INT AUTO_INCREMENT,
    cranio TINYINT(1),
    face TINYINT(1),
    regiao_occipital TINYINT(1),
    ombro_direito TINYINT(1),
    ombro_esquerdo TINYINT(1),
    braco_direito TINYINT(1),
    braco_esquerdo TINYINT(1),
    antebraco_direito TINYINT(1),
    antebraco_esquerdo TINYINT(1),
    punho_direito TINYINT(1),
    punho_esquerdo TINYINT(1),
    mao_direita TINYINT(1),
    mao_esquerda TINYINT(1),
    peitoral TINYINT(1),
    abdomen TINYINT(1),
    regiao_escapular TINYINT(1),
    regiao_cervical TINYINT(1),
    regiao_toracica TINYINT(1),
    regiao_lombar TINYINT(1),
    regiao_sacral TINYINT(1),
    regiao_coccigea TINYINT(1),
    regiao_glutea TINYINT(1),
    regiao_dorsal TINYINT(1),
    quadril TINYINT(1),
    coxa_anterior_direita TINYINT(1),
    coxa_anterior_esquerda TINYINT(1),
    coxa_posterior_direita TINYINT(1),
    coxa_posterior_esquerda TINYINT(1),
    coxa_lateral_direita TINYINT(1),
    coxa_lateral_esquerda TINYINT(1),
    coxa_medial_direita TINYINT(1),
    coxa_medial_esquerda TINYINT(1),
    perna_anterior_direita TINYINT(1),
    perna_anterior_esquerda TINYINT(1),
    perna_posterior_direita TINYINT(1),
    perna_posterior_esquerda TINYINT(1),
    tornozelo_direito TINYINT(1),
    tornozelo_esquerdo TINYINT(1),
    pe_direito TINYINT(1),
    pe_esquerdo TINYINT(1),
    PRIMARY KEY (id_partesCorpo)
);

