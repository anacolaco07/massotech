<?php
include "../Config.php";

$email = $_POST["email"];
$senha = md5($_POST["senha"]);
$select = $pdo->prepare("SELECT * FROM tb_usuario WHERE email = ? and senha = ?");
$select->bindParam(1, $email);
$select->bindParam(2, $senha);
$select->execute();

$user = $select->fetch();

if ($select->rowCount() > 0) {
            // Iniciar a sessão
            session_start();
            
            // Armazenar o ID do usuário na sessão
            $_SESSION['user_id'] = $user_id;
            
            header("Location: ../main_page/index.php");
            exit;
    } else {
        // Senha incorreta
        echo "Erro na autenticação";
    }


?>
