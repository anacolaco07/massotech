<?php

echo "<a href='/massotech/prontuario/prontuario_form.php'>Novo Prontuário</a>";
