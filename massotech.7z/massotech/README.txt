# Massotech

O Massotech é um sistema em desenvolvimento, projetado especificamente para atender
às necessidades dos estudantes e professores do curso subsequente de técnico em massoterapia.
Seu principal objetivo é automatizar e simplificar tarefas como o cadastro de formulários,
agendamento de sessões, registro de prontuários e criação de relatórios,
visando proporcionar economia de tempo e esforço ao longo das sessões de massagem.

## REQUISITOS
XAMPP Control Panel v3.3.0
MySQL Workbench 8.0 CE
PHP 7.2
Windows 10

## Installation

## Usage


## CONTRIBUIÇÕES

Contribuições são bem-vindas!
Se você encontrar um bug ou tiver sugestões, por favor envie um email para "email".
