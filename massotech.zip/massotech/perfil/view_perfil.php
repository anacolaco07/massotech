<?php
session_start();

require_once "../Config.php";

if (isset($_SESSION['id'])) {
    $id = $_SESSION['id'];
    $query = "SELECT * FROM tb_usuario WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":id", $id);
    $stmt->execute();
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario) {
        echo "<h1>Seu Perfil</h1>";
        echo "<p>Nome: " . $usuario['nome'] . "</p>";
        echo "<p>E-mail: " . $usuario['email'] . "</p>";
        echo "<p>Telefone: " . $usuario['telefone'] . "</p>";

        echo "<a href='../perfil/editar_form.php'>Editar</a>";
        echo "<br/>";
        echo "<br/><a href='../main_page/index.php'>Voltar</a>";
    } else {
        echo "Usuário não encontrado.";
    }
} else {
    echo "Sessão 'id' não está definida. Você deve estar autenticado para visualizar esta página.";
}
?>
