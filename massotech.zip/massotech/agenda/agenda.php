<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Agenda</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">Menu</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="#">Item 1</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Item 2</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Item 3</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container">
        <h2>Agenda</h2>
        <form action="../agenda/validacao.php" method="post">
            <label for="idPaciente">ID do Paciente</label>
            <input type="number" name="id_paciente" id="id_paciente">
            <br>
            <label for="procedimento">Massagem</label>
            <select name="procedimento">
                <option value="valor1" selected>Massagem Laboral</option>
                <option value="valor2">Massagem Shiatsu</option>
                <option value="valor3">Massagem Tuiná</option>
            </select>
            <br>
            <label for="dataHoraAgendamento">Data e Hora</label>
            <input type="datetime-local" name="dataHoraAgendamento" id="dataHoraAgendamento">
            <br>
            <input type="submit" value="Agendar">
        </form>
        <a href="../main_page/index.php">Voltar</a>
    </div>
</body>
</html>
