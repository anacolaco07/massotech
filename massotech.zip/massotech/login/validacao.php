<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    $host = "localhost:3306";
    $usuario = "root";
    $senhaBanco = "Dozico@12";
    $banco = "projeto_login";

    $conexao = new mysqli($host, $usuario, $senhaBanco, $banco);

    if ($conexao->connect_error) {
        die("Erro na conexão com o banco de dados: " . $conexao->connect_error);
    }

    $consulta = "SELECT id, senha FROM usuarios WHERE email = ?";
    $stmt = $conexao->prepare($consulta);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $senha_hash);

    if ($stmt->num_rows == 1) {
        $stmt->fetch();

        if (password_verify($senha, $senha_hash)) {
            $_SESSION["id_usuario"] = $id;
            header("Location: ../main_page/index.php");
        } else {
            echo "Senha incorreta";
        }
    } else {
        echo "Email não encontrado";
    }

    $stmt->close();
    $conexao->close();
}
?>
