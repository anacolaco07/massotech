<!DOCTYPE html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login</title>

	<link rel="stylesheet" href="inicio.css">

</head>
<body>
	<div>
		
		<form action="../login/validacao.php" method="post">
			<input type="email" name="email" placeholder="Email" maxlength="42" />
			<br /> 
			<input type="password" name="senha" placeholder="Senha" maxlength="15">
			<br />
			<input type="submit" name="acessar" value="Acessar" /><br />
			<a href="../cadastro/usuario_form.php">CADASTRE-SE</a>
		</form>	
		
	</div>


</body>
</html>

