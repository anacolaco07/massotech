<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Cadastro de usuário</title>

    <script>
    function validarFormulario() {
        var nome = document.getElementById("nome").value;
        var email = document.getElementById("email").value;
        var telefone = document.getElementById("telefone").value;
        var senha = document.getElementById("senha").value;
        var confSenha = document.getElementById("confSenha").value;

        if (nome === "" || email === "" || telefone === "" || senha === "" || confSenha === "") {
            alert("Por favor, preencha todos os campos.");
            return false;
        }

        var emailFormat = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        if (!email.match(emailFormat)) {
            alert("Formato de email inválido.");
            return false;
        }

        if (!/^\d+$/.test(telefone)) {
            alert("O telefone deve conter apenas dígitos.");
            return false;
        }

        if (senha !== confSenha) {
            alert("A senha e a confirmação de senha não coincidem.");
            return false;
        }

        return true;
    }
    </script>
    <link href='https://fonts.googleapis.com/css?family=Oswald'
	rel='stylesheet'>
    <link rel="stylesheet" href="cadastro.css">
    <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>

    <div class="box_cadastro">
        <h1>Cadastro de usuário</h1>
        <form action="../cadastro/salvar.php" method="post" onsubmit="return validarFormulario()">
            <input type="text" name="nome" placeholder="Nome Completo" maxlength="40" required/> 
            <input type="email" name="email" placeholder="Email" maxlength="42" required/>
            <input type="text" name="telefone" placeholder="Telefone" maxlength="30" required/>
            <input type="password" name="senha" placeholder="Senha" maxlength="15" required/> 
            <input type="password" name="confSenha" placeholder="Confirmar Senha" required/>
            <button class="btn-cadastro">CONFIRMAR</button>
            <button class="btn-cancelar" type="button" onclick="window.location.href='../login/login.php'">CANCELAR</button>
        </form>
    </div>
</body>
</html>
