<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $telefone = $_POST["telefone"];
    $senha = $_POST["senha"];
    $confSenha = $_POST["confSenha"];

    if (empty($nome) || empty($email) || empty($telefone) || empty($senha) || empty($confSenha)) {
        echo "Erro: Por favor, preencha todos os campos.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Erro: Formato de email inválido.";
    } elseif (!preg_match("/^[0-9]+$/", $telefone)) {
        echo "Erro: O telefone deve conter apenas dígitos.";
    } elseif ($senha !== $confSenha) {
        echo "Erro: A senha e a confirmação de senha não coincidem.";
    } else {
       
        $host = "localhost:3306";
        $usuario = "root";
        $senhaBanco = "";
        $banco = "projeto_login";

        $conexao = new mysqli($host, $usuario, $senhaBanco, $banco);

        if ($conexao->connect_error) {
            die("Erro na conexão com o banco de dados: " . $conexao->connect_error);
        }

        $inserir = "INSERT INTO tb_usuario (nome, email, telefone, senha) VALUES ('$nome', '$email', '$telefone', '$senha')";


        if ($conexao->query($inserir) === true) {
            echo "Registro bem-sucedido!";

            echo("<script language='JavaScript'>
            <!--
            alert('Sucesso!');
            window.location = '../login/login.php';
            //-->
            </script>");

            
        } 
      
 else {
            echo "Erro na inserção: " . $conexao->error;
        }

        $conexao->close();
    }
}
?>
